# IEEE LaTeX Assignment Example

Files:
- `main.tex` : Main IEEE-format paper
- `references.bib` : References kept separately in BibTeX format

Compile:
1. pdflatex main.tex
2. bibtex main
3. pdflatex main.tex
4. pdflatex main.tex

Or use Overleaf and upload both files, then compile `main.tex`.
